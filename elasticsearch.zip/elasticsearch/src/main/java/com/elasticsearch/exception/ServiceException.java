package com.elasticsearch.exception;

import org.springframework.http.HttpStatus;

public class ServiceException extends Exception {

   private static final long serialVersionUID = 8413976746913860125L;

   private  HttpStatus httpstatus = null;
   
   public ServiceException(String message) {
      super(message);
   }
   
   public ServiceException(Throwable cause) {
      super(cause);
   }

   public ServiceException(String msg, Throwable cause) {
      super(msg, cause);
   }

   public ServiceException(String msg, Throwable cause, HttpStatus status) {
	      super(msg, cause);
	      this.httpstatus = status;
   }

   public ServiceException(String msg,  HttpStatus status) {
	      super(msg);
	      this.httpstatus = status;
   }
   
   public HttpStatus getStatus(){
	   return httpstatus;
   }

}
