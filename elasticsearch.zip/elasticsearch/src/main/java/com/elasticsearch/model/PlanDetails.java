package com.elasticsearch.model;

public class PlanDetails {
	
	private String ackId;
	private String planName;
	private String sponsorName;
	private String sponsorState;
	
	public PlanDetails(){ }

	public String getAckId() {
		return ackId;
	}

	public void setAckId(String ackId) {
		this.ackId = ackId;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public String getSponsorName() {
		return sponsorName;
	}

	public void setSponsorName(String sponsorName) {
		this.sponsorName = sponsorName;
	}

	public String getSponsorState() {
		return sponsorState;
	}

	public void setSponsorState(String sponsorState) {
		this.sponsorState = sponsorState;
	}

	@Override
	public String toString() {
		return "PlanDetails [ackId=" + ackId + ", planName=" + planName
				+ ", sponsorName=" + sponsorName + ", sponsorState="
				+ sponsorState + "]";
	}
	
	
	
}
