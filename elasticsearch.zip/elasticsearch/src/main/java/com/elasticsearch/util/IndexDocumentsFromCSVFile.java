package com.elasticsearch.util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Collections;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.entity.ContentType;
import org.apache.http.nio.entity.NStringEntity;
import org.elasticsearch.client.RestClient;

import com.elasticsearch.model.PlanDetails;
import com.google.gson.Gson;

public class IndexDocumentsFromCSVFile {

	private static final String ENDPOINT = "search-pss-vault-dev-poc-awyrdjq33y3dtmy7q7kgrqnrzi.us-east-1.es.amazonaws.com";
	private static final String INDEX_NAME = "plans";
	private static final String TYPE = "plan";

	private static final String PATH_TO_CSV_FILE = "/Users/ravinder.varkali/Desktop/f_5500_2016_latest.csv";
	private static final String SEPARATOR = ",";
	
	private static RestClient client = null;
	public static void main(String[] args) {
		BufferedReader br = null;
		String line = "";
		int count = 0;
		try {
			client = RestClient.builder(new HttpHost(ENDPOINT, 443, "https")).build();
			br = new BufferedReader(new FileReader(PATH_TO_CSV_FILE));
			Gson gson = new Gson();
			
			while ((line = br.readLine()) != null) {
				String[] parser = line.split(SEPARATOR);
				String ackId = parser[0];
				String planName = parser[15];
				String sponserName = parser[18];
				String sponserState = parser[24];
				try {
					if(ackId != null && ackId.contains("\""))
						ackId = ackId.substring(1, ackId.length() - 1);
					
					if(planName != null && planName.contains("\""))
						planName = planName.substring(1, planName.length() - 1);
					
					if(sponserName != null && sponserName.contains("\""))
						sponserName = sponserName.substring(1, sponserName.length() - 1);
					
					if(sponserState != null && sponserState.contains("\""))
						sponserState = sponserState.substring(1, sponserState.length() - 1);
						
					PlanDetails pDetails = new PlanDetails();
					pDetails.setAckId(ackId);
					pDetails.setPlanName(planName);
					pDetails.setSponsorName(sponserName);
					pDetails.setSponsorState(sponserState);
					String plan = gson.toJson(pDetails);
					indexPlanDetails(plan, ackId); // index documents
					count ++;
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			if(br != null){
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		System.out.println("Done ... Number of Documents Indexed = " + count);
	}

	public static void indexPlanDetails(String plan, String ackId) throws Exception {
		HttpEntity entity = new NStringEntity(plan,ContentType.APPLICATION_JSON);
		//Response response = 
		client.performRequest("PUT", "/" + INDEX_NAME + "/"	+ TYPE + "/" + ackId, Collections.<String, String> emptyMap(), entity);
		//System.out.println(response.toString());
	}

}
