package com.elasticsearch.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.elasticsearch.model.PlanDetails;
import com.elasticsearch.service.SearchService;
import com.elasticsearch.service.ValidationService;

/**
 * Description :  Contains the APIs required to query the elasticsearch 
 * @author ravinder.varkali
 */
@RestController
@RequestMapping("/v1")
public class SearchController {
	
	private static final Logger logger = LogManager.getLogger(SearchController.class);
	
	@Autowired
	private SearchService searchService;
	
	@Autowired
	private ValidationService validationService;
	
	/**
	 * API to search in all fields
	 * @param query : the input query as request parameter
	 * @return List<PlanDetails> that match the given query
	 */
	@RequestMapping(value = "/search", method = RequestMethod.GET, consumes = { "application/json"} )
	public ResponseEntity<List<PlanDetails>> search(
			@RequestParam(value = "query", required = true)final String query) {
		
		logger.info("Search request with query string = " +query);
		
		List<PlanDetails> searchResults = new ArrayList<PlanDetails>();
		HttpStatus status = HttpStatus.OK;
		
		if(query == null || query.length() == 0)
			return new ResponseEntity<List<PlanDetails>>(searchResults, HttpStatus.BAD_REQUEST);
		try {
			searchResults = searchService.search(query);
		}catch(Exception e){
			logger.error("Error while processing the query", e);
			return new ResponseEntity<List<PlanDetails>>(searchResults, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<List<PlanDetails>>(searchResults, status);
	}
	
	/**
	 * API to search based on the specific fields (plan_name or sponsorName or sponsorState)
	 * @param planDetails - request body with searchable parameters
	 * @return List<PlanDetails> that match the given query
	 */
	@RequestMapping(value = "/search", method = RequestMethod.POST, consumes = { "application/json"})
	public ResponseEntity<List<PlanDetails>> search(
			@RequestBody PlanDetails planDetails) {
		
		logger.info("Search request with specific field, query parameter = " +planDetails.toString());
		List<PlanDetails> searchResults = new ArrayList<PlanDetails>();
		HttpStatus status = HttpStatus.OK;
		
		if(!validationService.isValidQuery(planDetails)){
			return new ResponseEntity<List<PlanDetails>>(searchResults, HttpStatus.BAD_REQUEST);
		}
		try {
			searchResults = searchService.search(planDetails);
		}catch(Exception e){
			logger.error("Error while processing the query", e);
			return new ResponseEntity<List<PlanDetails>>(searchResults, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<List<PlanDetails>>(searchResults, status);
	}
	
}
