package com.elasticsearch.service;

import com.elasticsearch.model.PlanDetails;

/**
 * Interface to validate the input queries
 * @author ravinder.varkali
 */

public interface ValidationService {
	/**
	 * To validate the input query
	 * @param query : String
	 * @return true/false
	 */
	public boolean isValidQuery(String query);
	
	/**
	 * Validate the input query, for specific fieds or all search fields
	 * @param planDetails
	 * @return true/false
	 */
	public boolean isValidQuery(PlanDetails planDetails);

}
