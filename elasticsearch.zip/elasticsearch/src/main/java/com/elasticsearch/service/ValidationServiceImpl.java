package com.elasticsearch.service;

import org.springframework.stereotype.Service;

import com.elasticsearch.model.PlanDetails;

/**
 * ValidationService implementation - to validate the input query
 * @author ravinder.varkali
 */
@Service("validationService")
public class ValidationServiceImpl implements ValidationService {
	
	/**
	 * Check for null or empty String
	 */
	public boolean isValidQuery(String query){
		return query != null && query.trim().length() > 0;
	}
	
	/**
	 * Check for null or empty String on all search fields
	 */
	public boolean isValidQuery(PlanDetails planDetails){
		
		if(planDetails == null) return false;
		
		if((planDetails.getPlanName() == null || planDetails.getPlanName().trim().length() == 0) && 
				(planDetails.getSponsorName() == null || planDetails.getSponsorName().trim().length() == 0) &&
				(planDetails.getSponsorState() == null || planDetails.getSponsorState().trim().length() == 0) 	)
			
			return false;
		
		return true;
	}

}



