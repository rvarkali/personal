package com.elasticsearch.service;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Service;

import com.elasticsearch.exception.ServiceException;
import com.elasticsearch.model.PlanDetails;

@Service("searchService")
public class SearchServiceImpl implements SearchService {
	
	private static final Logger logger = LogManager.getLogger(SearchServiceImpl.class);

	// TODO : move the following fields to a property file
	private static final String ENDPOINT_URL = "https://search-pss-vault-dev-poc-awyrdjq33y3dtmy7q7kgrqnrzi.us-east-1.es.amazonaws.com/plans/plan/_search?q=";

	// TODO Use the pool for httpclient
	public List<PlanDetails> search(String query) throws ServiceException, ClientProtocolException, IOException {
		CloseableHttpClient client = HttpClientBuilder.create().build();
		String url = ENDPOINT_URL + query;
		HttpGet httpGet = new HttpGet(url);
		httpGet.addHeader("Content-Type", "application/json");
		HttpResponse response = client.execute(httpGet);
		String responseBody = inputStreamToString(response.getEntity().getContent());
		client.close();
		return parseResponse(responseBody);
	}

	public List<PlanDetails> search(PlanDetails planDetails) throws ServiceException, ClientProtocolException, IOException {
		String query = formatQuery(planDetails);
		if(query != null){
			return search(query);
		}
		return new ArrayList<PlanDetails>();
	}
	
	/**
	 * Build the query based on user input
	 * @param planDetails
	 * @return query as String
	 */
	private static String formatQuery(PlanDetails planDetails){
		StringBuilder sb = new StringBuilder();
		if(planDetails.getPlanName() != null && planDetails.getPlanName().length() > 0){
			sb.append("planName:").append(planDetails.getPlanName().trim());
			return sb.toString();
		} else if(planDetails.getSponsorName() != null && planDetails.getSponsorName().trim().length() > 0){
			sb.append("sponsorName:").append(planDetails.getSponsorName().trim());
			return sb.toString();
		}else if(planDetails.getSponsorState() != null && planDetails.getSponsorState().trim().length() > 0){
			sb.append("sponsorState:").append(planDetails.getSponsorState().trim());
			return sb.toString();
		} 
		return null;
	}

	/**
	 * parse the response stream and convert to string
	 */
	private static String inputStreamToString(InputStream in) throws IOException {
		StringWriter output = new StringWriter();
		InputStreamReader input = new InputStreamReader(in);
		char[] buffer = new char[1024 * 4];
		int n = 0;
		while (-1 != (n = input.read(buffer))) {
			output.write(buffer, 0, n);
		}
		return output.toString();
	}

	/**
	 *  Parse the elasticsearch response and convert to domain object.
	 * @param response
	 */
	private static List<PlanDetails> parseResponse(String response) {
		JSONObject json = new JSONObject(response);
		JSONObject hitsObj = json.getJSONObject("hits");
		JSONArray hitsArr = hitsObj.getJSONArray("hits");
		List<PlanDetails> searchResult = new ArrayList<PlanDetails>();
		
		if (hitsArr != null) {
			for (int i = 0; i < hitsArr.length(); i++) {
				PlanDetails pDetails = new PlanDetails();
				JSONObject plan = hitsArr.getJSONObject(i);
				JSONObject source = plan.getJSONObject("_source");
				pDetails.setAckId(source.getString("ackId"));
				pDetails.setPlanName(source.getString("planName"));
				pDetails.setSponsorName(source.getString("sponsorName"));
				pDetails.setSponsorState(source.getString("sponsorState"));
				searchResult.add(pDetails);
			}
		}
		logger.info("found records = " + searchResult.size());
		return searchResult;
	}

}
