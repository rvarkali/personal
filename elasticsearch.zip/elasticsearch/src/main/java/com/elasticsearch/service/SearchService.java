package com.elasticsearch.service;

import java.io.IOException;
import java.util.List;

import org.apache.http.client.ClientProtocolException;

import com.elasticsearch.exception.ServiceException;
import com.elasticsearch.model.PlanDetails;


public interface SearchService {
	
	public List<PlanDetails> search(String query) throws ServiceException, ClientProtocolException, IOException;
	
	public List<PlanDetails> search(PlanDetails planDetails) throws ServiceException, ClientProtocolException, IOException;
	
}
