package com.elasticsearch.controller;

import java.util.List;

import junit.framework.TestCase;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.elasticsearch.model.PlanDetails;
import com.elasticsearch.service.SearchServiceImpl;
import com.elasticsearch.service.ValidationServiceImpl;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes={SearchController.class, SearchServiceImpl.class, ValidationServiceImpl.class})
public class SearchControllerTest {
	
	@Autowired
	private SearchController searchController;

	@Test
	public void searchTest(){
		String query = "PROFIT";
		ResponseEntity<List<PlanDetails>> response = searchController.search(query);
		TestCase.assertEquals(HttpStatus.OK, response.getStatusCode());
		List<PlanDetails> plans = response.getBody();
		
		if(plans == null || plans.size() == 0 )  
			return ;

		boolean matchFound = false;
		for(PlanDetails plan : plans) {
			if(plan.getPlanName().contains(query) || 
					plan.getPlanName().contains(query) || 
					plan.getPlanName().contains(query)) {
				matchFound = true;
			}
		}
		TestCase.assertEquals(true, matchFound);
	}
	
	@Test
	public void searchByPlanNameTest(){
		PlanDetails query = new PlanDetails();
		String planName = "VINES";
		query.setPlanName(planName);
		ResponseEntity<List<PlanDetails>> response = searchController.search(query);
		TestCase.assertEquals(HttpStatus.OK, response.getStatusCode());
		List<PlanDetails> plans = response.getBody();
		if(plans == null || plans.size() == 0 )  
			return ;
		for(PlanDetails plan : plans){
			TestCase.assertEquals(true, plan.getPlanName().contains(planName));
		}
	}
	
	@Test
	public void searchBySponsorNameTest(){
		PlanDetails query = new PlanDetails();
		String sponsorName = "SELLON";
		query.setSponsorName(sponsorName);
		ResponseEntity<List<PlanDetails>> response = searchController.search(query);
		TestCase.assertEquals(HttpStatus.OK, response.getStatusCode());
		List<PlanDetails> plans = response.getBody();
		if(plans == null || plans.size() == 0 )  
			return ;
		for(PlanDetails plan : plans){
			TestCase.assertEquals(true, plan.getSponsorName().contains(sponsorName));
		}
	}
	
	@Test
	public void searchBySponsorStateTest(){
		PlanDetails query = new PlanDetails();
		String sponsorState = "CA";
		query.setSponsorState(sponsorState);
		ResponseEntity<List<PlanDetails>> response = searchController.search(query);
		TestCase.assertEquals(HttpStatus.OK, response.getStatusCode());
		List<PlanDetails> plans = response.getBody();
		if(plans == null || plans.size() == 0 )  
			return ;
		for(PlanDetails plan : plans){
			TestCase.assertEquals(true, plan.getSponsorState().contains(sponsorState));
		}
	}

}
